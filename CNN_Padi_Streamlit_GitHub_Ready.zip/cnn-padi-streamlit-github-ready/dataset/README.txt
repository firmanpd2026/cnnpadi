Letakkan dataset Kaggle di folder ini.

Cara mudah:
1. Jalankan: python download_dataset.py
2. Jika download manual dari Kaggle, ekstrak file zip ke folder dataset/ ini.

Struktur yang didukung otomatis:
dataset/
  Nama_Kelas_1/
    gambar1.jpg
  Nama_Kelas_2/
    gambar2.jpg

Jika dataset punya subfolder tambahan, script training akan mencari folder kelas secara otomatis.
