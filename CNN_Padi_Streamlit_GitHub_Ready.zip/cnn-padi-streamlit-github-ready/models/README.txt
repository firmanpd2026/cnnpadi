Folder ini akan berisi hasil training model:
- rice_disease_model.keras
- class_names.txt
- training_history.csv
- classification_report.csv
- confusion_matrix.csv
- dataset_summary.csv
- model_info.json

Jalankan: python train_model.py
